import { motion } from "framer-motion";
import "./Footer.css";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <p className="footer-text">&copy; {new Date().getFullYear()} Dubos Web Services. Tous droits réservés.</p>
        <nav className="footer-nav">
          <a href="mailto:contact@duboswebservices.com" className="footer-link">Me contacter</a>
          <a href="/mentions-legales" className="footer-link">Mentions légales</a>
          <a href="/portfolio" className="footer-link">Portfolio</a>
        </nav>
      </div>
    </footer>
  );
};

export default Footer;

